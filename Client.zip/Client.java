import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Client {
	private static final String delimiter = ",";

    public static void main(String[] args) {
    	
    	try {
            //Declaring and initialising file Readers
            ArrayList<Book> books = new ArrayList<>();
            Scanner scnr = new Scanner(System.in);
//please provide the csv file path
            File file = new File("filePath");
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line;
            String[] columns;
            int i = 0;

            //reading everyLine in csv file
            while ((line = br.readLine()) != null) {
                //splitting the row and storing values in array;
                columns = line.split(delimiter);

                if (i == 0) {
                    //skipping header in csv
                    i = 1;
                    continue;
                }

                //for every row adding reading its column values and creating book.author //objects and adding it to books
                //reading column values
                String firstName = columns[0];
                String lastName = columns[1];
                String title = columns[2];
                int year = Integer.parseInt(columns[3]);
                String publisher = columns[4];
                String genre = columns[5];
                double rating = Double.parseDouble(columns[6]);
                double price = Double.parseDouble(columns[7]);

                //creating author and book objects
                Author author = new Author(firstName, lastName);
                Book book = new Book(author, title, year, publisher, genre, rating, price);

                //adding book to books
                books.add(book);


            }
            //creating bookDatabase
            BookDatabase bookDatabase = new BookDatabase(books);


            //searching with genre
            System.out.println("genre books Data");
            ArrayList<Book> booksWithGenre = bookDatabase.search("sdh");
            System.out.println(booksWithGenre.toString());

            //searching with years
            System.out.println("Books in Range");
            ArrayList<Book> booksInGivenRange = bookDatabase.search(2000, 2010);
            System.out.println(booksInGivenRange.toString());

            //searching with author
            System.out.println("Books with Author");
            ArrayList<Book> booksWithAuthor = bookDatabase.search(new Author("Henry", "Louis"));
            System.out.println(booksWithAuthor);


            br.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
