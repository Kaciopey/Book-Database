import java.util.ArrayList;

/**
 * 
 */

/**
 * @author Princ
 *
 */
public class BookDatabase {
	private final ArrayList<Book> books;
	
	public BookDatabase() {
        this.books = new ArrayList<>();
    }
	public BookDatabase(ArrayList<Book> books) {
        this.books = books;
    }
	public void addBook(Book book) {
        this.books.add(book);
    }

    public void removeBook(Book book) {
        this.books.remove(book);
    }
    public ArrayList<Book> search(Author author) {
        ArrayList<Book> result = new ArrayList<>();
        //for every book we compare with author provided
        // if equal store it in result and return 
        for (Book book : books) {

            //this equals method is written in author class
            if (book.author.equals(author)) {
                result.add(book);
            }
        }
		return result;
    }
    public ArrayList<Book> search(int startYear, int endYear) {
        ArrayList<Book> result = new ArrayList<>();
        for (Book book : books) {

            if (book.year >= startYear && book.year <= endYear) {
                result.add(book);
            }
        }
        return result;
    }
    public ArrayList<Book> search(String genre) {
        ArrayList<Book> result = new ArrayList<>();
        for (Book book : books) {

            //it's a string equals method 
            if (book.genre.equals(genre)) {
                result.add(book);
            }
        }

        return result;
    }
    public String toString() {
        return "BookDatabase{" +
                "books=" + books.toString() +
                '}';
    }

}
