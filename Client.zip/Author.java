
public class Author {
	private String firstName;
	private String lastName;
	
	public Author(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
	public java.lang.String toString() {
        return "Author{" +
                "firstName='" + firstName + '\'' +
                ", LastName='" + lastName + '\'' +
                '}';
    }
}
